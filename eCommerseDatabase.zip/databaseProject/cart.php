<?php
print_r($_POST);

$conn = mysqli_connect("localhost","root","Jt190170253","myProducts");

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$account_username = $_POST['account_username'];
$product_id = $_POST['product_id'];
$quantity = filter_input(INPUT_POST, "quantity", FILTER_VALIDATE_INT);

if ($quantity === false || $quantity === null) {
    die("Invalid quantity.");
}

$sql = "INSERT INTO cart (account_username, product_id, quantity)
VALUES ('$account_username', '$product_id', '$quantity')";

$rs = mysqli_query($conn, $sql);

if ($rs) {
    echo "Record inserted successfully";
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}

mysqli_close($conn);

?>
