<?php
print_r($_POST);

$conn = mysqli_connect("localhost", "root", "Jt190170253", "myProducts");

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$name = $_POST['name'];
$description = $_POST['description'];
$price = filter_input(INPUT_POST, "price", FILTER_VALIDATE_INT);
$comment = $_POST['comment'];

// Check if price is valid
if ($price === false || $price === null) {
    die("Invalid price.");
}

$sql = "INSERT INTO products (name, description, price, comments) 
VALUES ('$name', '$description', '$price', '$comment')";

$rs = mysqli_query($conn, $sql);

if ($rs) {
    echo "Product record inserted successfully";
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}

mysqli_close($conn);
?>
