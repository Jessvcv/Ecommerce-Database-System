<?php
print_r($_POST);

$conn = mysqli_connect("localhost","root","Jt190170253","myProducts");

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

if ($_SERVER["REQUEST_METHOD"] == "GET") {
    if(isset($_GET['search'])){
        $search = $_GET['search'];

        // Search for records based on player name
        $sql_search = "SELECT * FROM products WHERE name LIKE '%$search%'";
        $result = $conn->query($sql_search);

        if ($result->num_rows > 0) {
            echo "<table><tr><th>ID</th><th>Name</th><th>Description</th><th>Price</th><th>Comments</th></tr>";
            while($row = $result->fetch_assoc()) {
                echo "<tr><td>".$row["id"]."</td><td>".$row["name"]."</td><td>".$row["description"]."</td><td>".$row["price"]."</td><td>".$row["comments"]."</td></tr>";
            }
            echo "</table>";
        } else {
            echo "No records found";
        }
    }
}

$conn->close();
?>