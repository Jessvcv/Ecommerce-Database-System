<?php
print_r($_POST);

// Create connection
$conn = mysqli_connect("localhost","root","Jt190170253","myProducts");

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$uname = $_POST['Uname'];
$pword = $_POST['PWord'];

// SQL to insert data into database
$sql = "INSERT INTO users (username, password) 
VALUES ('$uname', '$pword')";

$rs = mysqli_query($conn, $sql);

if ($rs) {
    echo "User record inserted successfully";
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}

mysqli_close($conn);

?>

