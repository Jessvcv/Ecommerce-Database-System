<?php

print_r($_POST);

// Create connection
$conn = mysqli_connect("localhost","root","Jt190170253","myProducts" );

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$product_id = filter_input(INPUT_POST, "product_id", FILTER_VALIDATE_INT);
$name = $_POST['name'];
$comment =$_POST['comment'];

if ($product_id === false || $product_id === null) {
    die("Invalid product ID.");
}

// SQL to insert data into database
$sql = "INSERT INTO comments (product_id, name, comment) 
VALUES ('$product_id', '$name', '$comment')";

$rs = mysqli_query($conn, $sql);

if ($rs) {
    echo "Comment inserted successfully";
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}

mysqli_close($conn);
?>
